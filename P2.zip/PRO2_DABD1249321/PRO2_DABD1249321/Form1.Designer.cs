﻿
namespace PRO2_DABD1249321
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.PB0_0 = new System.Windows.Forms.PictureBox();
            this.PB1_0 = new System.Windows.Forms.PictureBox();
            this.PB2_0 = new System.Windows.Forms.PictureBox();
            this.PB3_0 = new System.Windows.Forms.PictureBox();
            this.PB4_1 = new System.Windows.Forms.PictureBox();
            this.PB3_1 = new System.Windows.Forms.PictureBox();
            this.PB2_1 = new System.Windows.Forms.PictureBox();
            this.PB1_1 = new System.Windows.Forms.PictureBox();
            this.PB0_1 = new System.Windows.Forms.PictureBox();
            this.PB4_2 = new System.Windows.Forms.PictureBox();
            this.PB3_2 = new System.Windows.Forms.PictureBox();
            this.PB2_2 = new System.Windows.Forms.PictureBox();
            this.PB1_2 = new System.Windows.Forms.PictureBox();
            this.PB0_2 = new System.Windows.Forms.PictureBox();
            this.PB4_3 = new System.Windows.Forms.PictureBox();
            this.PB3_3 = new System.Windows.Forms.PictureBox();
            this.PB2_3 = new System.Windows.Forms.PictureBox();
            this.PB1_3 = new System.Windows.Forms.PictureBox();
            this.PB0_3 = new System.Windows.Forms.PictureBox();
            this.PB4_0 = new System.Windows.Forms.PictureBox();
            this.PB4_4 = new System.Windows.Forms.PictureBox();
            this.PB3_4 = new System.Windows.Forms.PictureBox();
            this.PB2_4 = new System.Windows.Forms.PictureBox();
            this.PB1_4 = new System.Windows.Forms.PictureBox();
            this.PB0_4 = new System.Windows.Forms.PictureBox();
            this.PB5_4 = new System.Windows.Forms.PictureBox();
            this.PB5_0 = new System.Windows.Forms.PictureBox();
            this.PB5_3 = new System.Windows.Forms.PictureBox();
            this.PB5_2 = new System.Windows.Forms.PictureBox();
            this.PB5_1 = new System.Windows.Forms.PictureBox();
            this.Robot1 = new System.Windows.Forms.PictureBox();
            this.Robot2 = new System.Windows.Forms.PictureBox();
            this.Robot3 = new System.Windows.Forms.PictureBox();
            this.Robot4 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.pictureBox31 = new System.Windows.Forms.PictureBox();
            this.pictureBox32 = new System.Windows.Forms.PictureBox();
            this.pictureBox33 = new System.Windows.Forms.PictureBox();
            this.pictureBox34 = new System.Windows.Forms.PictureBox();
            this.pictureBox35 = new System.Windows.Forms.PictureBox();
            this.pictureBox36 = new System.Windows.Forms.PictureBox();
            this.pictureBox37 = new System.Windows.Forms.PictureBox();
            this.pictureBox38 = new System.Windows.Forms.PictureBox();
            this.pictureBox39 = new System.Windows.Forms.PictureBox();
            this.pictureBox40 = new System.Windows.Forms.PictureBox();
            this.pictureBox41 = new System.Windows.Forms.PictureBox();
            this.pictureBox42 = new System.Windows.Forms.PictureBox();
            this.pictureBox43 = new System.Windows.Forms.PictureBox();
            this.pictureBox44 = new System.Windows.Forms.PictureBox();
            this.pictureBox45 = new System.Windows.Forms.PictureBox();
            this.pictureBox46 = new System.Windows.Forms.PictureBox();
            this.pictureBox47 = new System.Windows.Forms.PictureBox();
            this.pictureBox48 = new System.Windows.Forms.PictureBox();
            this.pictureBox49 = new System.Windows.Forms.PictureBox();
            this.pictureBox50 = new System.Windows.Forms.PictureBox();
            this.pictureBox51 = new System.Windows.Forms.PictureBox();
            this.pictureBox52 = new System.Windows.Forms.PictureBox();
            this.pictureBox53 = new System.Windows.Forms.PictureBox();
            this.pictureBox54 = new System.Windows.Forms.PictureBox();
            this.pictureBox55 = new System.Windows.Forms.PictureBox();
            this.pictureBox56 = new System.Windows.Forms.PictureBox();
            this.pictureBox57 = new System.Windows.Forms.PictureBox();
            this.pictureBox58 = new System.Windows.Forms.PictureBox();
            this.pictureBox59 = new System.Windows.Forms.PictureBox();
            this.pictureBox60 = new System.Windows.Forms.PictureBox();
            this.pictureBox61 = new System.Windows.Forms.PictureBox();
            this.pictureBox62 = new System.Windows.Forms.PictureBox();
            this.pictureBox63 = new System.Windows.Forms.PictureBox();
            this.pictureBox64 = new System.Windows.Forms.PictureBox();
            this.pictureBox65 = new System.Windows.Forms.PictureBox();
            this.pictureBox66 = new System.Windows.Forms.PictureBox();
            this.pictureBox67 = new System.Windows.Forms.PictureBox();
            this.pictureBox68 = new System.Windows.Forms.PictureBox();
            this.pictureBox69 = new System.Windows.Forms.PictureBox();
            this.pictureBox70 = new System.Windows.Forms.PictureBox();
            this.pictureBox71 = new System.Windows.Forms.PictureBox();
            this.pictureBox72 = new System.Windows.Forms.PictureBox();
            this.pictureBox73 = new System.Windows.Forms.PictureBox();
            this.pictureBox74 = new System.Windows.Forms.PictureBox();
            this.pictureBox75 = new System.Windows.Forms.PictureBox();
            this.pictureBox76 = new System.Windows.Forms.PictureBox();
            this.pictureBox77 = new System.Windows.Forms.PictureBox();
            this.pictureBox78 = new System.Windows.Forms.PictureBox();
            this.pictureBox79 = new System.Windows.Forms.PictureBox();
            this.pictureBox80 = new System.Windows.Forms.PictureBox();
            this.pictureBox81 = new System.Windows.Forms.PictureBox();
            this.pictureBox82 = new System.Windows.Forms.PictureBox();
            this.pictureBox83 = new System.Windows.Forms.PictureBox();
            this.pictureBox84 = new System.Windows.Forms.PictureBox();
            this.pictureBox85 = new System.Windows.Forms.PictureBox();
            this.pictureBox86 = new System.Windows.Forms.PictureBox();
            this.pictureBox87 = new System.Windows.Forms.PictureBox();
            this.pictureBox88 = new System.Windows.Forms.PictureBox();
            this.pictureBox89 = new System.Windows.Forms.PictureBox();
            this.pictureBox90 = new System.Windows.Forms.PictureBox();
            this.pictureBox91 = new System.Windows.Forms.PictureBox();
            this.pictureBox92 = new System.Windows.Forms.PictureBox();
            this.pictureBox93 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.TMRobot1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.PB0_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB1_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB2_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB3_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB4_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB3_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB2_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB1_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB0_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB4_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB3_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB2_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB1_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB0_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB4_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB3_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB2_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB1_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB0_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB4_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB4_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB3_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB2_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB1_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB0_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB5_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB5_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB5_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB5_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB5_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Robot1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Robot2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Robot3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Robot4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox40)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox41)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox43)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox45)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox46)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox47)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox48)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox49)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox50)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox52)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox53)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox54)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox55)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox56)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox57)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox58)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox59)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox60)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox61)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox62)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox63)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox64)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox65)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox66)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox67)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox68)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox69)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox70)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox71)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox72)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox73)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox74)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox75)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox76)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox77)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox78)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox79)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox80)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox81)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox82)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox83)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox84)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox85)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox86)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox87)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox88)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox89)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox90)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox91)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox92)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox93)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // PB0_0
            // 
            this.PB0_0.BackColor = System.Drawing.SystemColors.ControlDark;
            this.PB0_0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB0_0.Enabled = false;
            this.PB0_0.Location = new System.Drawing.Point(0, 0);
            this.PB0_0.Name = "PB0_0";
            this.PB0_0.Size = new System.Drawing.Size(89, 89);
            this.PB0_0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB0_0.TabIndex = 0;
            this.PB0_0.TabStop = false;
            this.PB0_0.Visible = false;
            this.PB0_0.Click += new System.EventHandler(this.PB0_0_Click);
            // 
            // PB1_0
            // 
            this.PB1_0.BackColor = System.Drawing.SystemColors.ControlDark;
            this.PB1_0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB1_0.Enabled = false;
            this.PB1_0.Location = new System.Drawing.Point(0, 85);
            this.PB1_0.Name = "PB1_0";
            this.PB1_0.Size = new System.Drawing.Size(89, 89);
            this.PB1_0.TabIndex = 1;
            this.PB1_0.TabStop = false;
            this.PB1_0.Visible = false;
            this.PB1_0.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // PB2_0
            // 
            this.PB2_0.BackColor = System.Drawing.SystemColors.ControlDark;
            this.PB2_0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB2_0.Enabled = false;
            this.PB2_0.Location = new System.Drawing.Point(0, 170);
            this.PB2_0.Name = "PB2_0";
            this.PB2_0.Size = new System.Drawing.Size(89, 89);
            this.PB2_0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB2_0.TabIndex = 2;
            this.PB2_0.TabStop = false;
            this.PB2_0.Visible = false;
            this.PB2_0.Click += new System.EventHandler(this.PB2_0_Click);
            // 
            // PB3_0
            // 
            this.PB3_0.BackColor = System.Drawing.SystemColors.ControlDark;
            this.PB3_0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB3_0.Enabled = false;
            this.PB3_0.ErrorImage = null;
            this.PB3_0.InitialImage = null;
            this.PB3_0.Location = new System.Drawing.Point(0, 255);
            this.PB3_0.Name = "PB3_0";
            this.PB3_0.Size = new System.Drawing.Size(89, 89);
            this.PB3_0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB3_0.TabIndex = 3;
            this.PB3_0.TabStop = false;
            this.PB3_0.Visible = false;
            this.PB3_0.Click += new System.EventHandler(this.PB3_0_Click);
            // 
            // PB4_1
            // 
            this.PB4_1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.PB4_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB4_1.Enabled = false;
            this.PB4_1.Location = new System.Drawing.Point(89, 697);
            this.PB4_1.Name = "PB4_1";
            this.PB4_1.Size = new System.Drawing.Size(89, 89);
            this.PB4_1.TabIndex = 9;
            this.PB4_1.TabStop = false;
            this.PB4_1.Visible = false;
            this.PB4_1.Click += new System.EventHandler(this.PB4_1_Click);
            // 
            // PB3_1
            // 
            this.PB3_1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.PB3_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB3_1.Enabled = false;
            this.PB3_1.Location = new System.Drawing.Point(89, 255);
            this.PB3_1.Name = "PB3_1";
            this.PB3_1.Size = new System.Drawing.Size(89, 89);
            this.PB3_1.TabIndex = 8;
            this.PB3_1.TabStop = false;
            this.PB3_1.Visible = false;
            this.PB3_1.Click += new System.EventHandler(this.PB3_1_Click);
            // 
            // PB2_1
            // 
            this.PB2_1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.PB2_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB2_1.Enabled = false;
            this.PB2_1.Location = new System.Drawing.Point(89, 170);
            this.PB2_1.Name = "PB2_1";
            this.PB2_1.Size = new System.Drawing.Size(89, 89);
            this.PB2_1.TabIndex = 7;
            this.PB2_1.TabStop = false;
            this.PB2_1.Visible = false;
            this.PB2_1.Click += new System.EventHandler(this.PB2_1_Click);
            // 
            // PB1_1
            // 
            this.PB1_1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.PB1_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB1_1.Enabled = false;
            this.PB1_1.Location = new System.Drawing.Point(89, 85);
            this.PB1_1.Name = "PB1_1";
            this.PB1_1.Size = new System.Drawing.Size(89, 89);
            this.PB1_1.TabIndex = 6;
            this.PB1_1.TabStop = false;
            this.PB1_1.Visible = false;
            this.PB1_1.Click += new System.EventHandler(this.pictureBox9_Click);
            // 
            // PB0_1
            // 
            this.PB0_1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.PB0_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB0_1.Enabled = false;
            this.PB0_1.Location = new System.Drawing.Point(89, 0);
            this.PB0_1.Name = "PB0_1";
            this.PB0_1.Size = new System.Drawing.Size(89, 89);
            this.PB0_1.TabIndex = 5;
            this.PB0_1.TabStop = false;
            this.PB0_1.Visible = false;
            this.PB0_1.Click += new System.EventHandler(this.PB0_1_Click);
            // 
            // PB4_2
            // 
            this.PB4_2.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.PB4_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB4_2.Enabled = false;
            this.PB4_2.Location = new System.Drawing.Point(176, 697);
            this.PB4_2.Name = "PB4_2";
            this.PB4_2.Size = new System.Drawing.Size(89, 89);
            this.PB4_2.TabIndex = 14;
            this.PB4_2.TabStop = false;
            this.PB4_2.Visible = false;
            this.PB4_2.Click += new System.EventHandler(this.pictureBox11_Click);
            // 
            // PB3_2
            // 
            this.PB3_2.BackColor = System.Drawing.SystemColors.ControlDark;
            this.PB3_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB3_2.Enabled = false;
            this.PB3_2.Location = new System.Drawing.Point(176, 255);
            this.PB3_2.Name = "PB3_2";
            this.PB3_2.Size = new System.Drawing.Size(89, 89);
            this.PB3_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB3_2.TabIndex = 13;
            this.PB3_2.TabStop = false;
            this.PB3_2.Visible = false;
            this.PB3_2.Click += new System.EventHandler(this.PB3_2_Click);
            // 
            // PB2_2
            // 
            this.PB2_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB2_2.Enabled = false;
            this.PB2_2.Image = ((System.Drawing.Image)(resources.GetObject("PB2_2.Image")));
            this.PB2_2.Location = new System.Drawing.Point(1504, 362);
            this.PB2_2.Name = "PB2_2";
            this.PB2_2.Size = new System.Drawing.Size(89, 89);
            this.PB2_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB2_2.TabIndex = 12;
            this.PB2_2.TabStop = false;
            this.PB2_2.Click += new System.EventHandler(this.PB2_2_Click);
            // 
            // PB1_2
            // 
            this.PB1_2.BackColor = System.Drawing.SystemColors.ControlDark;
            this.PB1_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB1_2.Enabled = false;
            this.PB1_2.Location = new System.Drawing.Point(176, 85);
            this.PB1_2.Name = "PB1_2";
            this.PB1_2.Size = new System.Drawing.Size(89, 89);
            this.PB1_2.TabIndex = 11;
            this.PB1_2.TabStop = false;
            this.PB1_2.Visible = false;
            this.PB1_2.Click += new System.EventHandler(this.pictureBox14_Click);
            // 
            // PB0_2
            // 
            this.PB0_2.BackColor = System.Drawing.SystemColors.ControlDark;
            this.PB0_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB0_2.Enabled = false;
            this.PB0_2.ErrorImage = null;
            this.PB0_2.InitialImage = null;
            this.PB0_2.Location = new System.Drawing.Point(176, -4);
            this.PB0_2.Name = "PB0_2";
            this.PB0_2.Size = new System.Drawing.Size(89, 89);
            this.PB0_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB0_2.TabIndex = 10;
            this.PB0_2.TabStop = false;
            this.PB0_2.Visible = false;
            this.PB0_2.Click += new System.EventHandler(this.PB0_2_Click);
            // 
            // PB4_3
            // 
            this.PB4_3.BackColor = System.Drawing.SystemColors.ControlDark;
            this.PB4_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB4_3.Enabled = false;
            this.PB4_3.Location = new System.Drawing.Point(265, 697);
            this.PB4_3.Name = "PB4_3";
            this.PB4_3.Size = new System.Drawing.Size(89, 89);
            this.PB4_3.TabIndex = 20;
            this.PB4_3.TabStop = false;
            this.PB4_3.Visible = false;
            this.PB4_3.Click += new System.EventHandler(this.pictureBox16_Click);
            // 
            // PB3_3
            // 
            this.PB3_3.BackColor = System.Drawing.SystemColors.ControlDark;
            this.PB3_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB3_3.Enabled = false;
            this.PB3_3.Location = new System.Drawing.Point(265, 255);
            this.PB3_3.Name = "PB3_3";
            this.PB3_3.Size = new System.Drawing.Size(89, 89);
            this.PB3_3.TabIndex = 19;
            this.PB3_3.TabStop = false;
            this.PB3_3.Visible = false;
            this.PB3_3.Click += new System.EventHandler(this.PB3_3_Click);
            // 
            // PB2_3
            // 
            this.PB2_3.BackColor = System.Drawing.SystemColors.ControlDark;
            this.PB2_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB2_3.Enabled = false;
            this.PB2_3.Location = new System.Drawing.Point(265, 170);
            this.PB2_3.Name = "PB2_3";
            this.PB2_3.Size = new System.Drawing.Size(89, 89);
            this.PB2_3.TabIndex = 18;
            this.PB2_3.TabStop = false;
            this.PB2_3.Visible = false;
            this.PB2_3.Click += new System.EventHandler(this.pictureBox18_Click);
            // 
            // PB1_3
            // 
            this.PB1_3.BackColor = System.Drawing.SystemColors.ControlDark;
            this.PB1_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB1_3.Enabled = false;
            this.PB1_3.Location = new System.Drawing.Point(265, 85);
            this.PB1_3.Name = "PB1_3";
            this.PB1_3.Size = new System.Drawing.Size(89, 89);
            this.PB1_3.TabIndex = 17;
            this.PB1_3.TabStop = false;
            this.PB1_3.Visible = false;
            this.PB1_3.Click += new System.EventHandler(this.PB1_3_Click);
            // 
            // PB0_3
            // 
            this.PB0_3.BackColor = System.Drawing.SystemColors.ControlDark;
            this.PB0_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB0_3.Enabled = false;
            this.PB0_3.Location = new System.Drawing.Point(265, 0);
            this.PB0_3.Name = "PB0_3";
            this.PB0_3.Size = new System.Drawing.Size(89, 89);
            this.PB0_3.TabIndex = 16;
            this.PB0_3.TabStop = false;
            this.PB0_3.Visible = false;
            this.PB0_3.Click += new System.EventHandler(this.PB0_3_Click);
            // 
            // PB4_0
            // 
            this.PB4_0.BackColor = System.Drawing.SystemColors.ControlDark;
            this.PB4_0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB4_0.Enabled = false;
            this.PB4_0.Location = new System.Drawing.Point(0, 697);
            this.PB4_0.Name = "PB4_0";
            this.PB4_0.Size = new System.Drawing.Size(89, 89);
            this.PB4_0.TabIndex = 21;
            this.PB4_0.TabStop = false;
            this.PB4_0.Visible = false;
            this.PB4_0.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // PB4_4
            // 
            this.PB4_4.BackColor = System.Drawing.SystemColors.ControlDark;
            this.PB4_4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB4_4.Enabled = false;
            this.PB4_4.Location = new System.Drawing.Point(799, 697);
            this.PB4_4.Name = "PB4_4";
            this.PB4_4.Size = new System.Drawing.Size(89, 89);
            this.PB4_4.TabIndex = 26;
            this.PB4_4.TabStop = false;
            this.PB4_4.Visible = false;
            this.PB4_4.Click += new System.EventHandler(this.pictureBox21_Click);
            // 
            // PB3_4
            // 
            this.PB3_4.BackColor = System.Drawing.SystemColors.ControlDark;
            this.PB3_4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB3_4.Enabled = false;
            this.PB3_4.ErrorImage = null;
            this.PB3_4.InitialImage = null;
            this.PB3_4.Location = new System.Drawing.Point(354, 255);
            this.PB3_4.Name = "PB3_4";
            this.PB3_4.Size = new System.Drawing.Size(89, 89);
            this.PB3_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB3_4.TabIndex = 25;
            this.PB3_4.TabStop = false;
            this.PB3_4.Visible = false;
            this.PB3_4.Click += new System.EventHandler(this.pictureBox22_Click);
            // 
            // PB2_4
            // 
            this.PB2_4.BackColor = System.Drawing.SystemColors.ControlDark;
            this.PB2_4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB2_4.Enabled = false;
            this.PB2_4.ErrorImage = null;
            this.PB2_4.InitialImage = null;
            this.PB2_4.Location = new System.Drawing.Point(354, 171);
            this.PB2_4.Name = "PB2_4";
            this.PB2_4.Size = new System.Drawing.Size(89, 89);
            this.PB2_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB2_4.TabIndex = 24;
            this.PB2_4.TabStop = false;
            this.PB2_4.Visible = false;
            this.PB2_4.Click += new System.EventHandler(this.PB2_4_Click);
            // 
            // PB1_4
            // 
            this.PB1_4.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.PB1_4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB1_4.Enabled = false;
            this.PB1_4.Location = new System.Drawing.Point(354, 85);
            this.PB1_4.Name = "PB1_4";
            this.PB1_4.Size = new System.Drawing.Size(89, 89);
            this.PB1_4.TabIndex = 23;
            this.PB1_4.TabStop = false;
            this.PB1_4.Visible = false;
            this.PB1_4.Click += new System.EventHandler(this.PB1_4_Click);
            // 
            // PB0_4
            // 
            this.PB0_4.BackColor = System.Drawing.SystemColors.ControlDark;
            this.PB0_4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB0_4.Enabled = false;
            this.PB0_4.Location = new System.Drawing.Point(354, 0);
            this.PB0_4.Name = "PB0_4";
            this.PB0_4.Size = new System.Drawing.Size(89, 89);
            this.PB0_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB0_4.TabIndex = 22;
            this.PB0_4.TabStop = false;
            this.PB0_4.Visible = false;
            this.PB0_4.Click += new System.EventHandler(this.pictureBox25_Click);
            // 
            // PB5_4
            // 
            this.PB5_4.BackColor = System.Drawing.SystemColors.ControlDark;
            this.PB5_4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB5_4.Enabled = false;
            this.PB5_4.ErrorImage = null;
            this.PB5_4.InitialImage = null;
            this.PB5_4.Location = new System.Drawing.Point(354, 786);
            this.PB5_4.Name = "PB5_4";
            this.PB5_4.Size = new System.Drawing.Size(89, 89);
            this.PB5_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB5_4.TabIndex = 31;
            this.PB5_4.TabStop = false;
            this.PB5_4.Visible = false;
            this.PB5_4.Click += new System.EventHandler(this.pictureBox26_Click);
            // 
            // PB5_0
            // 
            this.PB5_0.BackColor = System.Drawing.SystemColors.ControlDark;
            this.PB5_0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB5_0.Enabled = false;
            this.PB5_0.ErrorImage = null;
            this.PB5_0.InitialImage = null;
            this.PB5_0.Location = new System.Drawing.Point(0, 786);
            this.PB5_0.Name = "PB5_0";
            this.PB5_0.Size = new System.Drawing.Size(89, 89);
            this.PB5_0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB5_0.TabIndex = 30;
            this.PB5_0.TabStop = false;
            this.PB5_0.Visible = false;
            this.PB5_0.Click += new System.EventHandler(this.PB5_0_Click);
            // 
            // PB5_3
            // 
            this.PB5_3.BackColor = System.Drawing.SystemColors.ControlDark;
            this.PB5_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB5_3.Enabled = false;
            this.PB5_3.Location = new System.Drawing.Point(265, 786);
            this.PB5_3.Name = "PB5_3";
            this.PB5_3.Size = new System.Drawing.Size(89, 89);
            this.PB5_3.TabIndex = 29;
            this.PB5_3.TabStop = false;
            this.PB5_3.Visible = false;
            this.PB5_3.Click += new System.EventHandler(this.pictureBox28_Click);
            // 
            // PB5_2
            // 
            this.PB5_2.BackColor = System.Drawing.SystemColors.ControlDark;
            this.PB5_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB5_2.Enabled = false;
            this.PB5_2.ErrorImage = null;
            this.PB5_2.InitialImage = null;
            this.PB5_2.Location = new System.Drawing.Point(176, 786);
            this.PB5_2.Name = "PB5_2";
            this.PB5_2.Size = new System.Drawing.Size(89, 89);
            this.PB5_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB5_2.TabIndex = 28;
            this.PB5_2.TabStop = false;
            this.PB5_2.Visible = false;
            this.PB5_2.Click += new System.EventHandler(this.pictureBox29_Click);
            // 
            // PB5_1
            // 
            this.PB5_1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.PB5_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB5_1.Enabled = false;
            this.PB5_1.Location = new System.Drawing.Point(89, 786);
            this.PB5_1.Name = "PB5_1";
            this.PB5_1.Size = new System.Drawing.Size(89, 89);
            this.PB5_1.TabIndex = 27;
            this.PB5_1.TabStop = false;
            this.PB5_1.Visible = false;
            this.PB5_1.Click += new System.EventHandler(this.pictureBox30_Click);
            // 
            // Robot1
            // 
            this.Robot1.Image = ((System.Drawing.Image)(resources.GetObject("Robot1.Image")));
            this.Robot1.Location = new System.Drawing.Point(932, 233);
            this.Robot1.Name = "Robot1";
            this.Robot1.Size = new System.Drawing.Size(66, 68);
            this.Robot1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Robot1.TabIndex = 32;
            this.Robot1.TabStop = false;
            // 
            // Robot2
            // 
            this.Robot2.Image = ((System.Drawing.Image)(resources.GetObject("Robot2.Image")));
            this.Robot2.Location = new System.Drawing.Point(933, 324);
            this.Robot2.Name = "Robot2";
            this.Robot2.Size = new System.Drawing.Size(65, 65);
            this.Robot2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Robot2.TabIndex = 33;
            this.Robot2.TabStop = false;
            // 
            // Robot3
            // 
            this.Robot3.Image = ((System.Drawing.Image)(resources.GetObject("Robot3.Image")));
            this.Robot3.Location = new System.Drawing.Point(933, 412);
            this.Robot3.Name = "Robot3";
            this.Robot3.Size = new System.Drawing.Size(65, 65);
            this.Robot3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Robot3.TabIndex = 34;
            this.Robot3.TabStop = false;
            // 
            // Robot4
            // 
            this.Robot4.Image = ((System.Drawing.Image)(resources.GetObject("Robot4.Image")));
            this.Robot4.Location = new System.Drawing.Point(933, 504);
            this.Robot4.Name = "Robot4";
            this.Robot4.Size = new System.Drawing.Size(65, 65);
            this.Robot4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Robot4.TabIndex = 35;
            this.Robot4.TabStop = false;
            this.Robot4.Click += new System.EventHandler(this.Robot4_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Enabled = false;
            this.pictureBox2.Location = new System.Drawing.Point(443, 786);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(89, 89);
            this.pictureBox2.TabIndex = 37;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Enabled = false;
            this.pictureBox1.Location = new System.Drawing.Point(532, 786);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(89, 89);
            this.pictureBox1.TabIndex = 38;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox4.Enabled = false;
            this.pictureBox4.Location = new System.Drawing.Point(621, 786);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(89, 89);
            this.pictureBox4.TabIndex = 39;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Visible = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox5.Enabled = false;
            this.pictureBox5.Location = new System.Drawing.Point(710, 786);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(89, 89);
            this.pictureBox5.TabIndex = 40;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Visible = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox10.Enabled = false;
            this.pictureBox10.Location = new System.Drawing.Point(799, 786);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(89, 89);
            this.pictureBox10.TabIndex = 41;
            this.pictureBox10.TabStop = false;
            this.pictureBox10.Visible = false;
            // 
            // pictureBox15
            // 
            this.pictureBox15.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox15.Enabled = false;
            this.pictureBox15.Location = new System.Drawing.Point(0, 341);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(89, 89);
            this.pictureBox15.TabIndex = 42;
            this.pictureBox15.TabStop = false;
            this.pictureBox15.Visible = false;
            // 
            // pictureBox18
            // 
            this.pictureBox18.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox18.Enabled = false;
            this.pictureBox18.Location = new System.Drawing.Point(0, 430);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(89, 89);
            this.pictureBox18.TabIndex = 43;
            this.pictureBox18.TabStop = false;
            this.pictureBox18.Visible = false;
            // 
            // pictureBox31
            // 
            this.pictureBox31.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox31.Enabled = false;
            this.pictureBox31.Location = new System.Drawing.Point(0, 519);
            this.pictureBox31.Name = "pictureBox31";
            this.pictureBox31.Size = new System.Drawing.Size(89, 89);
            this.pictureBox31.TabIndex = 44;
            this.pictureBox31.TabStop = false;
            this.pictureBox31.Visible = false;
            // 
            // pictureBox32
            // 
            this.pictureBox32.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox32.Enabled = false;
            this.pictureBox32.Location = new System.Drawing.Point(0, 608);
            this.pictureBox32.Name = "pictureBox32";
            this.pictureBox32.Size = new System.Drawing.Size(89, 89);
            this.pictureBox32.TabIndex = 45;
            this.pictureBox32.TabStop = false;
            this.pictureBox32.Visible = false;
            // 
            // pictureBox33
            // 
            this.pictureBox33.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox33.Enabled = false;
            this.pictureBox33.Location = new System.Drawing.Point(799, 608);
            this.pictureBox33.Name = "pictureBox33";
            this.pictureBox33.Size = new System.Drawing.Size(89, 89);
            this.pictureBox33.TabIndex = 46;
            this.pictureBox33.TabStop = false;
            this.pictureBox33.Visible = false;
            // 
            // pictureBox34
            // 
            this.pictureBox34.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox34.Enabled = false;
            this.pictureBox34.Location = new System.Drawing.Point(799, 519);
            this.pictureBox34.Name = "pictureBox34";
            this.pictureBox34.Size = new System.Drawing.Size(89, 89);
            this.pictureBox34.TabIndex = 47;
            this.pictureBox34.TabStop = false;
            this.pictureBox34.Visible = false;
            // 
            // pictureBox35
            // 
            this.pictureBox35.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox35.Enabled = false;
            this.pictureBox35.Location = new System.Drawing.Point(799, 430);
            this.pictureBox35.Name = "pictureBox35";
            this.pictureBox35.Size = new System.Drawing.Size(89, 89);
            this.pictureBox35.TabIndex = 48;
            this.pictureBox35.TabStop = false;
            this.pictureBox35.Visible = false;
            // 
            // pictureBox36
            // 
            this.pictureBox36.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox36.Enabled = false;
            this.pictureBox36.Location = new System.Drawing.Point(799, 341);
            this.pictureBox36.Name = "pictureBox36";
            this.pictureBox36.Size = new System.Drawing.Size(89, 89);
            this.pictureBox36.TabIndex = 49;
            this.pictureBox36.TabStop = false;
            this.pictureBox36.Visible = false;
            // 
            // pictureBox37
            // 
            this.pictureBox37.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox37.Enabled = false;
            this.pictureBox37.Location = new System.Drawing.Point(799, 255);
            this.pictureBox37.Name = "pictureBox37";
            this.pictureBox37.Size = new System.Drawing.Size(89, 89);
            this.pictureBox37.TabIndex = 50;
            this.pictureBox37.TabStop = false;
            this.pictureBox37.Visible = false;
            // 
            // pictureBox38
            // 
            this.pictureBox38.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox38.Enabled = false;
            this.pictureBox38.Location = new System.Drawing.Point(799, 170);
            this.pictureBox38.Name = "pictureBox38";
            this.pictureBox38.Size = new System.Drawing.Size(89, 89);
            this.pictureBox38.TabIndex = 51;
            this.pictureBox38.TabStop = false;
            this.pictureBox38.Visible = false;
            // 
            // pictureBox39
            // 
            this.pictureBox39.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox39.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox39.Enabled = false;
            this.pictureBox39.Location = new System.Drawing.Point(799, 85);
            this.pictureBox39.Name = "pictureBox39";
            this.pictureBox39.Size = new System.Drawing.Size(89, 89);
            this.pictureBox39.TabIndex = 52;
            this.pictureBox39.TabStop = false;
            this.pictureBox39.Visible = false;
            // 
            // pictureBox40
            // 
            this.pictureBox40.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox40.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox40.Enabled = false;
            this.pictureBox40.Location = new System.Drawing.Point(799, -2);
            this.pictureBox40.Name = "pictureBox40";
            this.pictureBox40.Size = new System.Drawing.Size(89, 89);
            this.pictureBox40.TabIndex = 53;
            this.pictureBox40.TabStop = false;
            this.pictureBox40.Visible = false;
            // 
            // pictureBox41
            // 
            this.pictureBox41.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox41.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox41.Enabled = false;
            this.pictureBox41.Location = new System.Drawing.Point(710, 170);
            this.pictureBox41.Name = "pictureBox41";
            this.pictureBox41.Size = new System.Drawing.Size(89, 89);
            this.pictureBox41.TabIndex = 60;
            this.pictureBox41.TabStop = false;
            this.pictureBox41.Visible = false;
            // 
            // pictureBox42
            // 
            this.pictureBox42.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox42.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox42.Enabled = false;
            this.pictureBox42.Location = new System.Drawing.Point(710, 255);
            this.pictureBox42.Name = "pictureBox42";
            this.pictureBox42.Size = new System.Drawing.Size(89, 89);
            this.pictureBox42.TabIndex = 59;
            this.pictureBox42.TabStop = false;
            this.pictureBox42.Visible = false;
            // 
            // pictureBox43
            // 
            this.pictureBox43.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox43.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox43.Enabled = false;
            this.pictureBox43.Location = new System.Drawing.Point(710, 430);
            this.pictureBox43.Name = "pictureBox43";
            this.pictureBox43.Size = new System.Drawing.Size(89, 89);
            this.pictureBox43.TabIndex = 58;
            this.pictureBox43.TabStop = false;
            this.pictureBox43.Visible = false;
            // 
            // pictureBox44
            // 
            this.pictureBox44.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox44.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox44.Enabled = false;
            this.pictureBox44.Location = new System.Drawing.Point(710, 341);
            this.pictureBox44.Name = "pictureBox44";
            this.pictureBox44.Size = new System.Drawing.Size(89, 89);
            this.pictureBox44.TabIndex = 57;
            this.pictureBox44.TabStop = false;
            this.pictureBox44.Visible = false;
            // 
            // pictureBox45
            // 
            this.pictureBox45.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox45.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox45.Enabled = false;
            this.pictureBox45.Location = new System.Drawing.Point(710, 519);
            this.pictureBox45.Name = "pictureBox45";
            this.pictureBox45.Size = new System.Drawing.Size(89, 89);
            this.pictureBox45.TabIndex = 56;
            this.pictureBox45.TabStop = false;
            this.pictureBox45.Visible = false;
            // 
            // pictureBox46
            // 
            this.pictureBox46.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox46.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox46.Enabled = false;
            this.pictureBox46.Location = new System.Drawing.Point(710, 608);
            this.pictureBox46.Name = "pictureBox46";
            this.pictureBox46.Size = new System.Drawing.Size(89, 89);
            this.pictureBox46.TabIndex = 55;
            this.pictureBox46.TabStop = false;
            this.pictureBox46.Visible = false;
            // 
            // pictureBox47
            // 
            this.pictureBox47.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox47.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox47.Enabled = false;
            this.pictureBox47.Location = new System.Drawing.Point(710, 697);
            this.pictureBox47.Name = "pictureBox47";
            this.pictureBox47.Size = new System.Drawing.Size(89, 89);
            this.pictureBox47.TabIndex = 54;
            this.pictureBox47.TabStop = false;
            this.pictureBox47.Visible = false;
            // 
            // pictureBox48
            // 
            this.pictureBox48.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox48.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox48.Enabled = false;
            this.pictureBox48.Location = new System.Drawing.Point(710, 85);
            this.pictureBox48.Name = "pictureBox48";
            this.pictureBox48.Size = new System.Drawing.Size(89, 89);
            this.pictureBox48.TabIndex = 61;
            this.pictureBox48.TabStop = false;
            this.pictureBox48.Visible = false;
            // 
            // pictureBox49
            // 
            this.pictureBox49.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox49.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox49.Enabled = false;
            this.pictureBox49.Location = new System.Drawing.Point(710, -1);
            this.pictureBox49.Name = "pictureBox49";
            this.pictureBox49.Size = new System.Drawing.Size(89, 89);
            this.pictureBox49.TabIndex = 62;
            this.pictureBox49.TabStop = false;
            this.pictureBox49.Visible = false;
            // 
            // pictureBox50
            // 
            this.pictureBox50.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox50.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox50.Enabled = false;
            this.pictureBox50.Location = new System.Drawing.Point(621, -1);
            this.pictureBox50.Name = "pictureBox50";
            this.pictureBox50.Size = new System.Drawing.Size(89, 89);
            this.pictureBox50.TabIndex = 70;
            this.pictureBox50.TabStop = false;
            this.pictureBox50.Visible = false;
            // 
            // pictureBox51
            // 
            this.pictureBox51.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox51.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox51.Enabled = false;
            this.pictureBox51.Location = new System.Drawing.Point(621, 83);
            this.pictureBox51.Name = "pictureBox51";
            this.pictureBox51.Size = new System.Drawing.Size(89, 89);
            this.pictureBox51.TabIndex = 69;
            this.pictureBox51.TabStop = false;
            this.pictureBox51.Visible = false;
            // 
            // pictureBox52
            // 
            this.pictureBox52.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox52.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox52.Enabled = false;
            this.pictureBox52.Location = new System.Drawing.Point(621, 170);
            this.pictureBox52.Name = "pictureBox52";
            this.pictureBox52.Size = new System.Drawing.Size(89, 89);
            this.pictureBox52.TabIndex = 68;
            this.pictureBox52.TabStop = false;
            this.pictureBox52.Visible = false;
            // 
            // pictureBox53
            // 
            this.pictureBox53.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox53.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox53.Enabled = false;
            this.pictureBox53.Location = new System.Drawing.Point(621, 255);
            this.pictureBox53.Name = "pictureBox53";
            this.pictureBox53.Size = new System.Drawing.Size(89, 89);
            this.pictureBox53.TabIndex = 67;
            this.pictureBox53.TabStop = false;
            this.pictureBox53.Visible = false;
            // 
            // pictureBox54
            // 
            this.pictureBox54.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox54.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox54.Enabled = false;
            this.pictureBox54.Location = new System.Drawing.Point(621, 430);
            this.pictureBox54.Name = "pictureBox54";
            this.pictureBox54.Size = new System.Drawing.Size(89, 89);
            this.pictureBox54.TabIndex = 66;
            this.pictureBox54.TabStop = false;
            this.pictureBox54.Visible = false;
            // 
            // pictureBox55
            // 
            this.pictureBox55.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox55.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox55.Enabled = false;
            this.pictureBox55.Location = new System.Drawing.Point(621, 341);
            this.pictureBox55.Name = "pictureBox55";
            this.pictureBox55.Size = new System.Drawing.Size(89, 89);
            this.pictureBox55.TabIndex = 65;
            this.pictureBox55.TabStop = false;
            this.pictureBox55.Visible = false;
            // 
            // pictureBox56
            // 
            this.pictureBox56.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox56.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox56.Enabled = false;
            this.pictureBox56.Location = new System.Drawing.Point(621, 519);
            this.pictureBox56.Name = "pictureBox56";
            this.pictureBox56.Size = new System.Drawing.Size(89, 89);
            this.pictureBox56.TabIndex = 64;
            this.pictureBox56.TabStop = false;
            this.pictureBox56.Visible = false;
            // 
            // pictureBox57
            // 
            this.pictureBox57.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox57.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox57.Enabled = false;
            this.pictureBox57.Location = new System.Drawing.Point(621, 608);
            this.pictureBox57.Name = "pictureBox57";
            this.pictureBox57.Size = new System.Drawing.Size(89, 89);
            this.pictureBox57.TabIndex = 63;
            this.pictureBox57.TabStop = false;
            this.pictureBox57.Visible = false;
            // 
            // pictureBox58
            // 
            this.pictureBox58.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox58.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox58.Enabled = false;
            this.pictureBox58.Location = new System.Drawing.Point(621, 697);
            this.pictureBox58.Name = "pictureBox58";
            this.pictureBox58.Size = new System.Drawing.Size(89, 89);
            this.pictureBox58.TabIndex = 71;
            this.pictureBox58.TabStop = false;
            this.pictureBox58.Visible = false;
            // 
            // pictureBox59
            // 
            this.pictureBox59.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox59.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox59.Enabled = false;
            this.pictureBox59.Location = new System.Drawing.Point(532, 697);
            this.pictureBox59.Name = "pictureBox59";
            this.pictureBox59.Size = new System.Drawing.Size(89, 89);
            this.pictureBox59.TabIndex = 80;
            this.pictureBox59.TabStop = false;
            this.pictureBox59.Visible = false;
            // 
            // pictureBox60
            // 
            this.pictureBox60.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox60.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox60.Enabled = false;
            this.pictureBox60.Location = new System.Drawing.Point(532, -2);
            this.pictureBox60.Name = "pictureBox60";
            this.pictureBox60.Size = new System.Drawing.Size(89, 89);
            this.pictureBox60.TabIndex = 79;
            this.pictureBox60.TabStop = false;
            this.pictureBox60.Visible = false;
            // 
            // pictureBox61
            // 
            this.pictureBox61.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox61.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox61.Enabled = false;
            this.pictureBox61.Location = new System.Drawing.Point(532, 83);
            this.pictureBox61.Name = "pictureBox61";
            this.pictureBox61.Size = new System.Drawing.Size(89, 89);
            this.pictureBox61.TabIndex = 78;
            this.pictureBox61.TabStop = false;
            this.pictureBox61.Visible = false;
            // 
            // pictureBox62
            // 
            this.pictureBox62.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox62.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox62.Enabled = false;
            this.pictureBox62.Location = new System.Drawing.Point(532, 169);
            this.pictureBox62.Name = "pictureBox62";
            this.pictureBox62.Size = new System.Drawing.Size(89, 89);
            this.pictureBox62.TabIndex = 77;
            this.pictureBox62.TabStop = false;
            this.pictureBox62.Visible = false;
            // 
            // pictureBox63
            // 
            this.pictureBox63.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox63.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox63.Enabled = false;
            this.pictureBox63.Location = new System.Drawing.Point(532, 254);
            this.pictureBox63.Name = "pictureBox63";
            this.pictureBox63.Size = new System.Drawing.Size(89, 89);
            this.pictureBox63.TabIndex = 76;
            this.pictureBox63.TabStop = false;
            this.pictureBox63.Visible = false;
            // 
            // pictureBox64
            // 
            this.pictureBox64.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox64.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox64.Enabled = false;
            this.pictureBox64.Location = new System.Drawing.Point(532, 430);
            this.pictureBox64.Name = "pictureBox64";
            this.pictureBox64.Size = new System.Drawing.Size(89, 89);
            this.pictureBox64.TabIndex = 75;
            this.pictureBox64.TabStop = false;
            this.pictureBox64.Visible = false;
            // 
            // pictureBox65
            // 
            this.pictureBox65.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox65.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox65.Enabled = false;
            this.pictureBox65.Location = new System.Drawing.Point(532, 341);
            this.pictureBox65.Name = "pictureBox65";
            this.pictureBox65.Size = new System.Drawing.Size(89, 89);
            this.pictureBox65.TabIndex = 74;
            this.pictureBox65.TabStop = false;
            this.pictureBox65.Visible = false;
            // 
            // pictureBox66
            // 
            this.pictureBox66.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox66.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox66.Enabled = false;
            this.pictureBox66.Location = new System.Drawing.Point(532, 519);
            this.pictureBox66.Name = "pictureBox66";
            this.pictureBox66.Size = new System.Drawing.Size(89, 89);
            this.pictureBox66.TabIndex = 73;
            this.pictureBox66.TabStop = false;
            this.pictureBox66.Visible = false;
            // 
            // pictureBox67
            // 
            this.pictureBox67.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox67.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox67.Enabled = false;
            this.pictureBox67.Location = new System.Drawing.Point(532, 608);
            this.pictureBox67.Name = "pictureBox67";
            this.pictureBox67.Size = new System.Drawing.Size(89, 89);
            this.pictureBox67.TabIndex = 72;
            this.pictureBox67.TabStop = false;
            this.pictureBox67.Visible = false;
            // 
            // pictureBox68
            // 
            this.pictureBox68.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox68.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox68.Enabled = false;
            this.pictureBox68.Location = new System.Drawing.Point(443, 697);
            this.pictureBox68.Name = "pictureBox68";
            this.pictureBox68.Size = new System.Drawing.Size(89, 89);
            this.pictureBox68.TabIndex = 89;
            this.pictureBox68.TabStop = false;
            this.pictureBox68.Visible = false;
            // 
            // pictureBox69
            // 
            this.pictureBox69.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox69.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox69.Enabled = false;
            this.pictureBox69.Location = new System.Drawing.Point(443, -2);
            this.pictureBox69.Name = "pictureBox69";
            this.pictureBox69.Size = new System.Drawing.Size(89, 89);
            this.pictureBox69.TabIndex = 88;
            this.pictureBox69.TabStop = false;
            this.pictureBox69.Visible = false;
            // 
            // pictureBox70
            // 
            this.pictureBox70.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox70.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox70.Enabled = false;
            this.pictureBox70.Location = new System.Drawing.Point(443, 83);
            this.pictureBox70.Name = "pictureBox70";
            this.pictureBox70.Size = new System.Drawing.Size(89, 89);
            this.pictureBox70.TabIndex = 87;
            this.pictureBox70.TabStop = false;
            this.pictureBox70.Visible = false;
            // 
            // pictureBox71
            // 
            this.pictureBox71.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox71.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox71.Enabled = false;
            this.pictureBox71.Location = new System.Drawing.Point(443, 169);
            this.pictureBox71.Name = "pictureBox71";
            this.pictureBox71.Size = new System.Drawing.Size(89, 89);
            this.pictureBox71.TabIndex = 86;
            this.pictureBox71.TabStop = false;
            this.pictureBox71.Visible = false;
            // 
            // pictureBox72
            // 
            this.pictureBox72.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox72.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox72.Location = new System.Drawing.Point(443, 253);
            this.pictureBox72.Name = "pictureBox72";
            this.pictureBox72.Size = new System.Drawing.Size(89, 89);
            this.pictureBox72.TabIndex = 85;
            this.pictureBox72.TabStop = false;
            this.pictureBox72.Visible = false;
            // 
            // pictureBox73
            // 
            this.pictureBox73.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox73.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox73.Enabled = false;
            this.pictureBox73.Location = new System.Drawing.Point(443, 430);
            this.pictureBox73.Name = "pictureBox73";
            this.pictureBox73.Size = new System.Drawing.Size(89, 89);
            this.pictureBox73.TabIndex = 84;
            this.pictureBox73.TabStop = false;
            this.pictureBox73.Visible = false;
            // 
            // pictureBox74
            // 
            this.pictureBox74.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox74.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox74.Enabled = false;
            this.pictureBox74.Location = new System.Drawing.Point(443, 341);
            this.pictureBox74.Name = "pictureBox74";
            this.pictureBox74.Size = new System.Drawing.Size(89, 89);
            this.pictureBox74.TabIndex = 83;
            this.pictureBox74.TabStop = false;
            this.pictureBox74.Visible = false;
            // 
            // pictureBox75
            // 
            this.pictureBox75.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox75.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox75.Enabled = false;
            this.pictureBox75.Location = new System.Drawing.Point(443, 519);
            this.pictureBox75.Name = "pictureBox75";
            this.pictureBox75.Size = new System.Drawing.Size(89, 89);
            this.pictureBox75.TabIndex = 82;
            this.pictureBox75.TabStop = false;
            this.pictureBox75.Visible = false;
            // 
            // pictureBox76
            // 
            this.pictureBox76.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox76.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox76.Enabled = false;
            this.pictureBox76.Location = new System.Drawing.Point(443, 608);
            this.pictureBox76.Name = "pictureBox76";
            this.pictureBox76.Size = new System.Drawing.Size(89, 89);
            this.pictureBox76.TabIndex = 81;
            this.pictureBox76.TabStop = false;
            this.pictureBox76.Visible = false;
            // 
            // pictureBox77
            // 
            this.pictureBox77.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox77.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox77.Enabled = false;
            this.pictureBox77.Location = new System.Drawing.Point(89, 608);
            this.pictureBox77.Name = "pictureBox77";
            this.pictureBox77.Size = new System.Drawing.Size(89, 89);
            this.pictureBox77.TabIndex = 93;
            this.pictureBox77.TabStop = false;
            this.pictureBox77.Visible = false;
            // 
            // pictureBox78
            // 
            this.pictureBox78.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox78.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox78.Enabled = false;
            this.pictureBox78.Location = new System.Drawing.Point(89, 519);
            this.pictureBox78.Name = "pictureBox78";
            this.pictureBox78.Size = new System.Drawing.Size(89, 89);
            this.pictureBox78.TabIndex = 92;
            this.pictureBox78.TabStop = false;
            this.pictureBox78.Visible = false;
            // 
            // pictureBox79
            // 
            this.pictureBox79.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox79.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox79.Enabled = false;
            this.pictureBox79.Location = new System.Drawing.Point(89, 430);
            this.pictureBox79.Name = "pictureBox79";
            this.pictureBox79.Size = new System.Drawing.Size(89, 89);
            this.pictureBox79.TabIndex = 91;
            this.pictureBox79.TabStop = false;
            this.pictureBox79.Visible = false;
            // 
            // pictureBox80
            // 
            this.pictureBox80.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox80.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox80.Enabled = false;
            this.pictureBox80.Location = new System.Drawing.Point(89, 341);
            this.pictureBox80.Name = "pictureBox80";
            this.pictureBox80.Size = new System.Drawing.Size(89, 89);
            this.pictureBox80.TabIndex = 90;
            this.pictureBox80.TabStop = false;
            this.pictureBox80.Visible = false;
            // 
            // pictureBox81
            // 
            this.pictureBox81.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox81.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox81.Enabled = false;
            this.pictureBox81.Location = new System.Drawing.Point(176, 608);
            this.pictureBox81.Name = "pictureBox81";
            this.pictureBox81.Size = new System.Drawing.Size(89, 89);
            this.pictureBox81.TabIndex = 97;
            this.pictureBox81.TabStop = false;
            this.pictureBox81.Visible = false;
            // 
            // pictureBox82
            // 
            this.pictureBox82.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox82.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox82.Enabled = false;
            this.pictureBox82.Location = new System.Drawing.Point(176, 519);
            this.pictureBox82.Name = "pictureBox82";
            this.pictureBox82.Size = new System.Drawing.Size(89, 89);
            this.pictureBox82.TabIndex = 96;
            this.pictureBox82.TabStop = false;
            this.pictureBox82.Visible = false;
            // 
            // pictureBox83
            // 
            this.pictureBox83.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox83.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox83.Enabled = false;
            this.pictureBox83.Location = new System.Drawing.Point(176, 430);
            this.pictureBox83.Name = "pictureBox83";
            this.pictureBox83.Size = new System.Drawing.Size(89, 89);
            this.pictureBox83.TabIndex = 95;
            this.pictureBox83.TabStop = false;
            this.pictureBox83.Visible = false;
            // 
            // pictureBox84
            // 
            this.pictureBox84.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox84.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox84.Enabled = false;
            this.pictureBox84.Location = new System.Drawing.Point(176, 341);
            this.pictureBox84.Name = "pictureBox84";
            this.pictureBox84.Size = new System.Drawing.Size(89, 89);
            this.pictureBox84.TabIndex = 94;
            this.pictureBox84.TabStop = false;
            this.pictureBox84.Visible = false;
            // 
            // pictureBox85
            // 
            this.pictureBox85.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox85.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox85.Enabled = false;
            this.pictureBox85.Location = new System.Drawing.Point(265, 608);
            this.pictureBox85.Name = "pictureBox85";
            this.pictureBox85.Size = new System.Drawing.Size(89, 89);
            this.pictureBox85.TabIndex = 101;
            this.pictureBox85.TabStop = false;
            this.pictureBox85.Visible = false;
            // 
            // pictureBox86
            // 
            this.pictureBox86.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox86.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox86.Enabled = false;
            this.pictureBox86.Location = new System.Drawing.Point(265, 519);
            this.pictureBox86.Name = "pictureBox86";
            this.pictureBox86.Size = new System.Drawing.Size(89, 89);
            this.pictureBox86.TabIndex = 100;
            this.pictureBox86.TabStop = false;
            this.pictureBox86.Visible = false;
            // 
            // pictureBox87
            // 
            this.pictureBox87.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox87.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox87.Location = new System.Drawing.Point(265, 430);
            this.pictureBox87.Name = "pictureBox87";
            this.pictureBox87.Size = new System.Drawing.Size(89, 89);
            this.pictureBox87.TabIndex = 99;
            this.pictureBox87.TabStop = false;
            this.pictureBox87.Visible = false;
            // 
            // pictureBox88
            // 
            this.pictureBox88.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox88.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox88.Enabled = false;
            this.pictureBox88.Location = new System.Drawing.Point(265, 341);
            this.pictureBox88.Name = "pictureBox88";
            this.pictureBox88.Size = new System.Drawing.Size(89, 89);
            this.pictureBox88.TabIndex = 98;
            this.pictureBox88.TabStop = false;
            this.pictureBox88.Visible = false;
            // 
            // pictureBox89
            // 
            this.pictureBox89.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox89.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox89.Enabled = false;
            this.pictureBox89.Location = new System.Drawing.Point(354, 608);
            this.pictureBox89.Name = "pictureBox89";
            this.pictureBox89.Size = new System.Drawing.Size(89, 89);
            this.pictureBox89.TabIndex = 106;
            this.pictureBox89.TabStop = false;
            this.pictureBox89.Visible = false;
            // 
            // pictureBox90
            // 
            this.pictureBox90.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox90.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox90.Enabled = false;
            this.pictureBox90.Location = new System.Drawing.Point(354, 519);
            this.pictureBox90.Name = "pictureBox90";
            this.pictureBox90.Size = new System.Drawing.Size(89, 89);
            this.pictureBox90.TabIndex = 105;
            this.pictureBox90.TabStop = false;
            this.pictureBox90.Visible = false;
            // 
            // pictureBox91
            // 
            this.pictureBox91.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox91.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox91.Enabled = false;
            this.pictureBox91.Location = new System.Drawing.Point(354, 430);
            this.pictureBox91.Name = "pictureBox91";
            this.pictureBox91.Size = new System.Drawing.Size(89, 89);
            this.pictureBox91.TabIndex = 104;
            this.pictureBox91.TabStop = false;
            this.pictureBox91.Visible = false;
            // 
            // pictureBox92
            // 
            this.pictureBox92.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox92.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox92.Enabled = false;
            this.pictureBox92.Location = new System.Drawing.Point(354, 341);
            this.pictureBox92.Name = "pictureBox92";
            this.pictureBox92.Size = new System.Drawing.Size(89, 89);
            this.pictureBox92.TabIndex = 103;
            this.pictureBox92.TabStop = false;
            this.pictureBox92.Visible = false;
            // 
            // pictureBox93
            // 
            this.pictureBox93.BackColor = System.Drawing.SystemColors.ControlDark;
            this.pictureBox93.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox93.Enabled = false;
            this.pictureBox93.Location = new System.Drawing.Point(354, 697);
            this.pictureBox93.Name = "pictureBox93";
            this.pictureBox93.Size = new System.Drawing.Size(89, 89);
            this.pictureBox93.TabIndex = 102;
            this.pictureBox93.TabStop = false;
            this.pictureBox93.Visible = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.SystemColors.ControlDark;
            this.pictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox3.Enabled = false;
            this.pictureBox3.Location = new System.Drawing.Point(176, 170);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(89, 87);
            this.pictureBox3.TabIndex = 107;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Visible = false;
            // 
            // TMRobot1
            // 
            this.TMRobot1.Enabled = true;
            this.TMRobot1.Interval = 1000;
            this.TMRobot1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1035, 877);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox89);
            this.Controls.Add(this.pictureBox90);
            this.Controls.Add(this.pictureBox91);
            this.Controls.Add(this.pictureBox92);
            this.Controls.Add(this.pictureBox93);
            this.Controls.Add(this.pictureBox85);
            this.Controls.Add(this.pictureBox86);
            this.Controls.Add(this.pictureBox87);
            this.Controls.Add(this.pictureBox88);
            this.Controls.Add(this.pictureBox81);
            this.Controls.Add(this.pictureBox82);
            this.Controls.Add(this.pictureBox83);
            this.Controls.Add(this.pictureBox84);
            this.Controls.Add(this.pictureBox77);
            this.Controls.Add(this.pictureBox78);
            this.Controls.Add(this.pictureBox79);
            this.Controls.Add(this.pictureBox80);
            this.Controls.Add(this.pictureBox68);
            this.Controls.Add(this.pictureBox69);
            this.Controls.Add(this.pictureBox70);
            this.Controls.Add(this.pictureBox71);
            this.Controls.Add(this.pictureBox72);
            this.Controls.Add(this.pictureBox73);
            this.Controls.Add(this.pictureBox74);
            this.Controls.Add(this.pictureBox75);
            this.Controls.Add(this.pictureBox76);
            this.Controls.Add(this.pictureBox59);
            this.Controls.Add(this.pictureBox60);
            this.Controls.Add(this.pictureBox61);
            this.Controls.Add(this.pictureBox62);
            this.Controls.Add(this.pictureBox63);
            this.Controls.Add(this.pictureBox64);
            this.Controls.Add(this.pictureBox65);
            this.Controls.Add(this.pictureBox66);
            this.Controls.Add(this.pictureBox67);
            this.Controls.Add(this.pictureBox58);
            this.Controls.Add(this.pictureBox50);
            this.Controls.Add(this.pictureBox51);
            this.Controls.Add(this.pictureBox52);
            this.Controls.Add(this.pictureBox53);
            this.Controls.Add(this.pictureBox54);
            this.Controls.Add(this.pictureBox55);
            this.Controls.Add(this.pictureBox56);
            this.Controls.Add(this.pictureBox57);
            this.Controls.Add(this.pictureBox49);
            this.Controls.Add(this.pictureBox48);
            this.Controls.Add(this.pictureBox41);
            this.Controls.Add(this.pictureBox42);
            this.Controls.Add(this.pictureBox43);
            this.Controls.Add(this.pictureBox44);
            this.Controls.Add(this.pictureBox45);
            this.Controls.Add(this.pictureBox46);
            this.Controls.Add(this.pictureBox47);
            this.Controls.Add(this.pictureBox40);
            this.Controls.Add(this.pictureBox39);
            this.Controls.Add(this.pictureBox38);
            this.Controls.Add(this.pictureBox37);
            this.Controls.Add(this.pictureBox36);
            this.Controls.Add(this.pictureBox35);
            this.Controls.Add(this.pictureBox34);
            this.Controls.Add(this.pictureBox33);
            this.Controls.Add(this.pictureBox32);
            this.Controls.Add(this.pictureBox31);
            this.Controls.Add(this.pictureBox18);
            this.Controls.Add(this.pictureBox15);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Robot4);
            this.Controls.Add(this.Robot3);
            this.Controls.Add(this.Robot2);
            this.Controls.Add(this.Robot1);
            this.Controls.Add(this.PB5_4);
            this.Controls.Add(this.PB5_0);
            this.Controls.Add(this.PB5_3);
            this.Controls.Add(this.PB5_2);
            this.Controls.Add(this.PB5_1);
            this.Controls.Add(this.PB4_4);
            this.Controls.Add(this.PB3_4);
            this.Controls.Add(this.PB2_4);
            this.Controls.Add(this.PB1_4);
            this.Controls.Add(this.PB0_4);
            this.Controls.Add(this.PB4_0);
            this.Controls.Add(this.PB4_3);
            this.Controls.Add(this.PB3_3);
            this.Controls.Add(this.PB2_3);
            this.Controls.Add(this.PB1_3);
            this.Controls.Add(this.PB0_3);
            this.Controls.Add(this.PB4_2);
            this.Controls.Add(this.PB3_2);
            this.Controls.Add(this.PB2_2);
            this.Controls.Add(this.PB1_2);
            this.Controls.Add(this.PB0_2);
            this.Controls.Add(this.PB4_1);
            this.Controls.Add(this.PB3_1);
            this.Controls.Add(this.PB2_1);
            this.Controls.Add(this.PB1_1);
            this.Controls.Add(this.PB0_1);
            this.Controls.Add(this.PB3_0);
            this.Controls.Add(this.PB2_0);
            this.Controls.Add(this.PB1_0);
            this.Controls.Add(this.PB0_0);
            this.Enabled = false;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.KeyPreview = true;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.PB0_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB1_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB2_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB3_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB4_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB3_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB2_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB1_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB0_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB4_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB3_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB2_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB1_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB0_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB4_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB3_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB2_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB1_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB0_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB4_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB4_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB3_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB2_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB1_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB0_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB5_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB5_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB5_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB5_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB5_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Robot1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Robot2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Robot3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Robot4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox40)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox41)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox43)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox45)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox46)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox47)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox48)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox49)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox50)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox52)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox53)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox54)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox55)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox56)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox57)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox58)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox59)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox60)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox61)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox62)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox63)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox64)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox65)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox66)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox67)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox68)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox69)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox70)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox71)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox72)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox73)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox74)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox75)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox76)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox77)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox78)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox79)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox80)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox81)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox82)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox83)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox84)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox85)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox86)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox87)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox88)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox89)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox90)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox91)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox92)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox93)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox PB0_0;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox PB2_;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox PB0_1;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox PB0_2;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.PictureBox PB2_3;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.PictureBox P;
        private System.Windows.Forms.PictureBox pictureBox21;
        private System.Windows.Forms.PictureBox pictureBox22;
        private System.Windows.Forms.PictureBox pictureBox23;
        private System.Windows.Forms.PictureBox pictureBox24;
        private System.Windows.Forms.PictureBox pictureBox25;
        private System.Windows.Forms.PictureBox pictureBox26;
        private System.Windows.Forms.PictureBox pictureBox27;
        private System.Windows.Forms.PictureBox pictureBox28;
        private System.Windows.Forms.PictureBox pictureBox29;
        private System.Windows.Forms.PictureBox pictureBox30;
        private System.Windows.Forms.PictureBox Robot1;
        private System.Windows.Forms.PictureBox PBConfig0_3;
        private System.Windows.Forms.PictureBox PBConfig0_0;
        private System.Windows.Forms.PictureBox PB0_3;
        private System.Windows.Forms.PictureBox PB0_4;
        private System.Windows.Forms.PictureBox PB1_0;
        private System.Windows.Forms.PictureBox PB1_1;
        private System.Windows.Forms.PictureBox PB2_0;
        private System.Windows.Forms.PictureBox PB2_1;
        private System.Windows.Forms.PictureBox PB2_2;
        private System.Windows.Forms.PictureBox PB1_2;
        private System.Windows.Forms.PictureBox PB1_3;
        private System.Windows.Forms.PictureBox PB1_4;
        private System.Windows.Forms.PictureBox PB3_0;
        private System.Windows.Forms.PictureBox PB3_1;
        private System.Windows.Forms.PictureBox PB3_2;
        private System.Windows.Forms.PictureBox PB2_4;
        private System.Windows.Forms.PictureBox PB3_3;
        private System.Windows.Forms.PictureBox PB3_4;
        private System.Windows.Forms.PictureBox PB4_0;
        private System.Windows.Forms.PictureBox PB4_1;
        private System.Windows.Forms.PictureBox PB4_2;
        private System.Windows.Forms.PictureBox PB4_3;
        private System.Windows.Forms.PictureBox PB4_4;
        private System.Windows.Forms.PictureBox PB5_0;
        private System.Windows.Forms.PictureBox PB5_1;
        private System.Windows.Forms.PictureBox PB5_2;
        private System.Windows.Forms.PictureBox PB5_3;
        private System.Windows.Forms.PictureBox PB5_4;
        private System.Windows.Forms.PictureBox Robot2;
        private System.Windows.Forms.PictureBox Robot3;
        private System.Windows.Forms.PictureBox Robot4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.PictureBox pictureBox31;
        private System.Windows.Forms.PictureBox pictureBox32;
        private System.Windows.Forms.PictureBox pictureBox33;
        private System.Windows.Forms.PictureBox pictureBox34;
        private System.Windows.Forms.PictureBox pictureBox35;
        private System.Windows.Forms.PictureBox pictureBox36;
        private System.Windows.Forms.PictureBox pictureBox37;
        private System.Windows.Forms.PictureBox pictureBox38;
        private System.Windows.Forms.PictureBox pictureBox39;
        private System.Windows.Forms.PictureBox pictureBox40;
        private System.Windows.Forms.PictureBox pictureBox41;
        private System.Windows.Forms.PictureBox pictureBox42;
        private System.Windows.Forms.PictureBox pictureBox43;
        private System.Windows.Forms.PictureBox pictureBox44;
        private System.Windows.Forms.PictureBox pictureBox45;
        private System.Windows.Forms.PictureBox pictureBox46;
        private System.Windows.Forms.PictureBox pictureBox47;
        private System.Windows.Forms.PictureBox pictureBox48;
        private System.Windows.Forms.PictureBox pictureBox49;
        private System.Windows.Forms.PictureBox pictureBox50;
        private System.Windows.Forms.PictureBox pictureBox51;
        private System.Windows.Forms.PictureBox pictureBox52;
        private System.Windows.Forms.PictureBox pictureBox53;
        private System.Windows.Forms.PictureBox pictureBox54;
        private System.Windows.Forms.PictureBox pictureBox55;
        private System.Windows.Forms.PictureBox pictureBox56;
        private System.Windows.Forms.PictureBox pictureBox57;
        private System.Windows.Forms.PictureBox pictureBox58;
        private System.Windows.Forms.PictureBox pictureBox59;
        private System.Windows.Forms.PictureBox pictureBox60;
        private System.Windows.Forms.PictureBox pictureBox61;
        private System.Windows.Forms.PictureBox pictureBox62;
        private System.Windows.Forms.PictureBox pictureBox63;
        private System.Windows.Forms.PictureBox pictureBox64;
        private System.Windows.Forms.PictureBox pictureBox65;
        private System.Windows.Forms.PictureBox pictureBox66;
        private System.Windows.Forms.PictureBox pictureBox67;
        private System.Windows.Forms.PictureBox pictureBox68;
        private System.Windows.Forms.PictureBox pictureBox69;
        private System.Windows.Forms.PictureBox pictureBox70;
        private System.Windows.Forms.PictureBox pictureBox71;
        private System.Windows.Forms.PictureBox pictureBox72;
        private System.Windows.Forms.PictureBox pictureBox73;
        private System.Windows.Forms.PictureBox pictureBox74;
        private System.Windows.Forms.PictureBox pictureBox75;
        private System.Windows.Forms.PictureBox pictureBox76;
        private System.Windows.Forms.PictureBox pictureBox77;
        private System.Windows.Forms.PictureBox pictureBox78;
        private System.Windows.Forms.PictureBox pictureBox79;
        private System.Windows.Forms.PictureBox pictureBox80;
        private System.Windows.Forms.PictureBox pictureBox81;
        private System.Windows.Forms.PictureBox pictureBox82;
        private System.Windows.Forms.PictureBox pictureBox83;
        private System.Windows.Forms.PictureBox pictureBox84;
        private System.Windows.Forms.PictureBox pictureBox85;
        private System.Windows.Forms.PictureBox pictureBox86;
        private System.Windows.Forms.PictureBox pictureBox87;
        private System.Windows.Forms.PictureBox pictureBox88;
        private System.Windows.Forms.PictureBox pictureBox89;
        private System.Windows.Forms.PictureBox pictureBox90;
        private System.Windows.Forms.PictureBox pictureBox91;
        private System.Windows.Forms.PictureBox pictureBox92;
        private System.Windows.Forms.PictureBox pictureBox93;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Timer TMRobot1;
    }
}

