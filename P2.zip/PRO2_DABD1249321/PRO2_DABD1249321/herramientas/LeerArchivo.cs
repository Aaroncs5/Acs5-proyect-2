﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace PRO2_DABD1249321.herramientas
{
    class LeerArchivo
    {
        string[,] MatrizParaLeer;
        
        public LeerArchivo()
        {

        }
        public void Leer(string ruta)
        {
            int contador = 0;
            var reader = new StreamReader(File.OpenRead(ruta));

            List<string> lista = new List<string>();

            while (!reader.EndOfStream)
            {
                var linea = reader.ReadLine();
                contador++;
                string[] valores = linea.Split(",");
                foreach (var i in valores)
                {
                    lista.Add(i);

                }
                    
            }


            int contador2 = 0;
            MatrizParaLeer = new string[contador, lista.Count / contador];
           for (int o = 0; o < contador; o++)
           {
                for (int x = 0; x < lista.Count/contador; x++)
                {
                    MatrizParaLeer[contador, lista.Count / contador] = lista;
                    contador2++;
                }

           }
            

            

            

        }

    }
    
}
