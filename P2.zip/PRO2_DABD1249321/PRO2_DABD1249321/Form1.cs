﻿using PRO2_DABD1249321.herramientas;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRO2_DABD1249321
{
    public partial class Form1 : Form
    {
        LeerArchivo archivo = new LeerArchivo();


        //Se crea una matriz global
        string[,] Configuracion;

        public static RichTextBox Salida;

        public Form1()
        {
            InitializeComponent();

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            int p0sicionX = Robot1.Location.X;
            int p0sicionY = Robot1.Location.Y;
            int NPocisionY = 0;
            int NPocisionX = 0;

            Keys t3cla = e.KeyCode;
            switch (t3cla)
            {
                case Keys.Down:
                    p0sicionY += 5;
                    Robot1.Location = new Point(p0sicionX,p0sicionY);
                    NPocisionY = 5;
                    DelimitarEnPasillos(Robot1, p0sicionX, p0sicionY, NPocisionX, NPocisionY);
                    break;
                case Keys.Up:
                    p0sicionY -= 5;
                    Robot1.Location = new Point(p0sicionX, p0sicionY);
                    NPocisionY = -5;
                    DelimitarEnPasillos(Robot1, p0sicionX, p0sicionY, NPocisionX, NPocisionY);
                    break;
                case Keys.Left:
                    p0sicionX -= 5;
                    Robot1.Location = new Point(p0sicionX, p0sicionY);
                    NPocisionX = -5;
                    DelimitarEnPasillos(Robot1, p0sicionX, p0sicionY, NPocisionX, NPocisionY);
                    break;
                case Keys.Right:
                    p0sicionX += 5;
                    Robot1.Location = new Point(p0sicionX, p0sicionY);
                    NPocisionX = 5;
                    DelimitarEnPasillos(Robot1, p0sicionX, p0sicionY, NPocisionX, NPocisionY);
                    break;

            }


        }
        public void DelimitarEnPasillos(PictureBox robotenU, int posX, int posY, int NposX, int NposY)
        {
            foreach (Control C0ntrol in this.Controls)
            {
                if (Robot1.Bounds.IntersectsWith(C0ntrol.Bounds))
                {
                    if(C0ntrol is PictureBox && C0ntrol != Robot1 && C0ntrol.Enabled && C0ntrol.Visible)
                    { 
                        MessageBox.Show("Has tocado una pared continua por el pasio. ");
                        NposX -= 5;
                        NposY -= 5;
                        Robot1.Location = new Point(posX, posY);

                    }
                }

            }

        }
        public string LeerArchivo(ref bool EstadoDeAccion)
        {
            EstadoDeAccion = false;
            try
            {
                string FileToRead = @"ProyectoB.csv";
                string Config = "";
                using (StreamReader ReaderObject = new StreamReader(FileToRead))
                {
                    string Line;

                    while ((Line = ReaderObject.ReadLine()) != null)
                    {
                        MessageBox.Show(Line);

                    }
                    if (Config != "")
                    {
                        EstadoDeAccion = true;
                    }

                    return Config;
                }
            }
            catch
            {
                EstadoDeAccion = false;
            }
            return "";

        }
        // Se crea una funcion ti
        private void CargarConfiguracion()
        {
            /* bool estad0 = false;
             string[,] CadenaConfig;
             string CadenaGuardar = "";
             int PosicionMatrizX = 0;
             int PosicionMatrizY = 0;
             if (estad0)
             {
                 try
                 {
                     for(int i=0; i < CadenaConfig.Length; i++)
                     {
                         for (int x = 0; x < CadenaConfig.GetLength(1); x++)
                         {
                             if (CadenaConfig[i,x].ToString() == ";" || CadenaConfig[i,x].ToString() == " ")
                             {
                                 CadenaGuardar = " ";
                                 PosicionMatrizX++;
                             }
                             else
                             {
                                 CadenaGuardar += CadenaConfig[i,x].ToString();
                             }
                             Configuracion[PosicionMatrizX, PosicionMatrizY] = CadenaGuardar;
                             if (PosicionMatrizX == 4)
                             {
                                 PosicionMatrizX++;
                                 PosicionMatrizX = 0;
                             }
                             // Utilizamos un break para que el ciclo se pueda parar y nop quede un bluque o ciclo infinito.
                             if (PosicionMatrizY == 6)
                             {
                                 break;
                             }
                         }


                     }
                     //
                     for (int u =0; u < Configuracion.GetLength(0); u++)
                     {
                         for (int Y = 0; Y < Configuracion.GetLength(1); Y++)
                         {

                         }
                     }

                 }
                 catch
                 {

                 }

             */

            var reader = new StreamReader(File.OpenRead(@"C:\Users\aaron\source\repos\PRO2_DABD1249321\PRO2_DABD1249321\bin\Debug\netcoreapp3.1\ProyectoB.csv"));
            List<string> listA = new List<string>();
            List<string> listB = new List<string>();
            while (!reader.EndOfStream)
            {
                var line = reader.ReadLine();
                var values = line.Split('');

                listA.Add(values[0]);
                listB.Add(values[1]);
                foreach (var coloumn1 in listA)
                {
                    Console.WriteLine(coloumn1);
                }
                foreach (var coloumn2 in listA)
                {
                    Console.WriteLine(coloumn2);
                }
            }







        }

        int[,] DatosdelCVS;
        PictureBox[,] MatrizCeldas = new PictureBox[10, 10];
        public void MatricesSegunParametros()
        {
            PictureBox[,] MatrizCeldas = { { PB0_0, PB0_1, PB0_2, PB0_3, PB0_4, pictureBox69, pictureBox60, pictureBox50, pictureBox49, pictureBox40 },
                             {PB1_0,PB1_1,PB1_2,PB1_3,PB1_4,pictureBox70,pictureBox61,pictureBox51,pictureBox48,pictureBox39},
                             { PB2_0,PB2_1,PB2_2,PB2_3,PB2_4,pictureBox71,pictureBox62,pictureBox52,pictureBox41,pictureBox38 },
                             { PB3_0,PB3_1,PB3_2,PB3_3,PB3_4,pictureBox72,pictureBox63,pictureBox53, pictureBox42,pictureBox37},
                             { pictureBox15,pictureBox80,pictureBox84,pictureBox88,pictureBox92,pictureBox74,pictureBox65,pictureBox55,pictureBox34,pictureBox36 },
                             { pictureBox18,pictureBox79,pictureBox83,pictureBox87,pictureBox91,pictureBox73,pictureBox64,pictureBox54,pictureBox43,pictureBox35 },
                             { pictureBox31,pictureBox78,pictureBox82,pictureBox86,pictureBox90,pictureBox75,pictureBox66,pictureBox56,pictureBox45,pictureBox34 },
                             { pictureBox32,pictureBox77,pictureBox81,pictureBox85,pictureBox89,pictureBox76,pictureBox67,pictureBox57,pictureBox46,pictureBox33 },
                             { PB4_0,PB4_1,PB4_2,PB4_3,pictureBox93,pictureBox68,pictureBox59,pictureBox58,pictureBox47,PB4_4},
                             { PB5_0,PB5_1,PB5_2,PB5_3,PB5_4,pictureBox2,pictureBox1,pictureBox4,pictureBox5,pictureBox10 } };

        }
        public void RecorerMatrizCeldas1()
        {
            for (int y = 0; y < DatosdelCVS.GetLength(0); y++)
            {
                for (int z = 0; z < DatosdelCVS.GetLength(1); z++)
                {
                    
                    {
                        MatrizCeldas[y, z].BackColor = Color.Beige;
                    }
                    

                }
            }

            for (int i =0; i<MatrizCeldas.GetLength(0); i++)
            {
                for(int x = 0; x < MatrizCeldas.GetLength(1); x++)
                {

                   
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CargarConfiguracion ();
        }

        private void pictureBox25_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox14_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox18_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox22_Click(object sender, EventArgs e)
        {

        }

        private void PB3_3_Click(object sender, EventArgs e)
        {

        }

        private void PB3_0_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox16_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox21_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox30_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox29_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox28_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox26_Click(object sender, EventArgs e)
        {

        }

        private void PB0_0_Click(object sender, EventArgs e)
        {

        }

        private void PB0_1_Click(object sender, EventArgs e)
        {

        }

        private void PB0_2_Click(object sender, EventArgs e)
        {

        }

        private void PB0_3_Click(object sender, EventArgs e)
        {

        }

        private void PB1_3_Click(object sender, EventArgs e)
        {

        }

        private void PB1_4_Click(object sender, EventArgs e)
        {

        }

        private void PB2_0_Click(object sender, EventArgs e)
        {

        }

        private void PB2_1_Click(object sender, EventArgs e)
        {

        }

        private void PB2_2_Click(object sender, EventArgs e)
        {

        }

        private void PB2_4_Click(object sender, EventArgs e)
        {

        }

        private void PB3_1_Click(object sender, EventArgs e)
        {

        }

        private void PB3_2_Click(object sender, EventArgs e)
        {

        }

        private void PB4_1_Click(object sender, EventArgs e)
        {

        }

        private void PB5_0_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox18_Click_1(object sender, EventArgs e)
        {

        }

        private void Robot4_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            int x = Robot1.Location.X;
            int y = Robot1.Location.Y;
            bool avanz4r = true;
            Robot1.Location = new Point(x - 100,y);
            if (x <= 536)
            {
                avanz4r = false;
            }

            if (avanz4r== false)
            {
                Robot1.Location = new Point(x, y + 100);
            }
            else if (avanz4r == false && y <= 786)
            {
                avanz4r =false; 
                Robot1.Location = new Point(x = 932, y = 233);
            }
                
                    

        }
    }

}
